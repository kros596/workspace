/*
 * Pese a poder evaluar las expresiones de las entradas mediante el atributo 'pattern', 'minlength', 'maxlength' y 'required', se han elaborado
 * las funciones de validaci�n, poder ejecutar las validaciones personalizadas que se estimen oportunas
 * Por ello, se ha indicado el atributo novalidate en el formulario, para evitar los eventos asociados por defecto
 */

//Al cargar el documento lo primero que hace es validar las entradas
document.addEventListener("DOMContentLoaded", function (event) {
    validateAllInputs();
});

function submitForm() {
    //Primero evalua la validez de las entradas de forma redundante por seguridad
    var result = validateAllInputs();

    if (result) {
        alert("Inscripcion realizada con exito!");
    } else {
        alert("Los campos introducidos no son correctos, corrijalos antes de continuar.")
    }
}

function validateAllInputs() {
    var result = true;
    //Sentencias if consecutivas para evitar que un resultado true pueda anular uno anterior false
    if (!validateName(document.getElementById("name"))) {
        result=false
    }
    if (!validateEmail(document.getElementById("email"))){
        result = false;
    }
    if (!validatePassword(document.getElementById("pwd"))) {
        result = false;
    }
    if (!validatePasswordConfirm(document.getElementById("pwdc"))) {
        result = false;
    }
    return result;
}

function validateName(el) {
    const regex = /^[a-zA-Z ]*$/;
    const errorEl = document.getElementById("nameErr");
    const divEl = el.closest('.input-wrapper');
    var result=true;
    if (el.value == null || el.value == "") {
        errorEl.innerHTML = "Rellene este campo";
        result=false;
    }
    if (result) {
        result = regex.test(el.value);
        if (!result) {
            errorEl.innerHTML = "El nombre solo puede contener letras may�sculas y min�sculas";
        }
    }
    
    if (!result) {
        errorEl.classList.remove("hide");
        errorEl.classList.add("show");
        divEl.classList.remove("valid");
        divEl.classList.add("invalid");
        return false;
    } else {
        errorEl.classList.remove("show");
        errorEl.classList.add("hide");
        divEl.classList.remove("invalid");
        divEl.classList.add("valid");
        errorEl.innerHTML = "";
        return true;
    }
}


function validateEmail(el) {
    var regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    const errorEl = document.getElementById("emailErr");
    const divEl = el.closest('.input-wrapper');
    var result=true;
    if (el.value == null || el.value == "") {
        result = false;
        errorEl.innerHTML = "Rellene este campo";
    }
    if (result) {
        result = regex.test(el.value);
        if (!result) {
            //Evalua el motivo por el cual el email no cumple el formato
            regex = /^[a-zA-Z0-9._-]+@/;
            if (!(regex.test(el.value))) {
                errorEl.innerHTML = "No cumple el formato: Debe incluir un simbolo @";
            } else {
                regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]/;
                if (!(regex.test(el.value))) {
                    errorEl.innerHTML = "No cumple el formato: Debe incluir un nombre del dominio, como '.gmail.com'";
                } else {
                    regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]/;
                    if (!(regex.test(el.value))) {
                        errorEl.innerHTML = "No cumple el formato: Debe incluir el sufijo, como '.com' o '.es'";
                    } else {
                        errorEl.innerHTML = "No cumple el formato: El sufijo debe tener entre 2 y 4 caracteres, como '.com' o '.es'";
                    }
                }
            }
        }
    }

    if (!result) {
        errorEl.classList.remove("hide");
        errorEl.classList.add("show");
        divEl.classList.remove("valid");
        divEl.classList.add("invalid");
        return false;
    } else {
        errorEl.classList.remove("show");
        errorEl.classList.add("hide");
        divEl.classList.remove("invalid");
        divEl.classList.add("valid");
        errorEl.innerHTML = "";
        return true;
    }
}

function validatePassword(el) {
    var regex = /^(?=.*\d)(?=.*[\u0021-\u002b\u003c-\u0040])(?=.*[A-Z])(?=.*[a-z])\S{8,}$/;
    const errorEl = document.getElementById("pwdErr");
    var divEl = el.closest('.input-wrapper');
    var result=true;
    if (el.value == null || el.value == "") {
        result=false
        errorEl.innerHTML = "Rellene este campo";
    }
    if (result) {
        result = (regex.test(el.value));
        if (!result) {
            errorEl.innerHTML = "La clave debe ser de al menos 8 caracteres y contener mayusculas, minusculas, numeros y simbolos.";
        }
    }

    if (!result) {
        errorEl.classList.remove("hide");
        errorEl.classList.add("show");
        divEl.classList.remove("valid");
        divEl.classList.add("invalid");
    } else {
        errorEl.classList.remove("show");
        errorEl.classList.add("hide");
        divEl.classList.remove("invalid");
        divEl.classList.add("valid");
        errorEl.innerHTML = "";
    }
    validatePasswordConfirm(document.getElementById("pwdc")); //Para comprobar si modificando la contrase�a ya coinciden
    return result;
}

function validatePasswordConfirm(el) {
    const errorEl = document.getElementById("pwdcErr");
    var divEl = el.closest('.input-wrapper');
    var result=true;
    if (el.value == null || el.value == "") {
        result = false
        errorEl.innerHTML = "Rellene este campo";
    }
    if (result) {
        if (!(el.value == document.getElementById("pwd").value)) {
            errorEl.innerHTML = "Las claves no coinciden";
            result = false;
        }
    }
    if (result) {
        //Si la clave no tiene el formato v�lido no valida esta entrada tampoco (lo hace comparando si contiene la clase invalid)
        if (document.getElementById("pwd").closest(".input-wrapper").classList.contains("invalid")) {
            errorEl.innerHTML = "La clave no cumple el formato requerido";
            result = false;
        }
    }
    

    if (!result) {
        errorEl.classList.remove("hide");
        errorEl.classList.add("show");
        divEl.classList.remove("valid");
        divEl.classList.add("invalid");
        return false;
    } else {
        errorEl.classList.remove("show");
        errorEl.classList.add("hide");
        divEl.classList.remove("invalid");
        divEl.classList.add("valid");
        errorEl.innerHTML = "";
        return true
    }
}